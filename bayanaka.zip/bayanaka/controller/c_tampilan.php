<?php

	include dirname(dirname(__FILE__)) . '../model/m_tampilan.php';
	include dirname(dirname(__FILE__)) . '../view/tampilan.php';
	
	class c_tampilan{
		function __construct(){
			
		}
	}
?>