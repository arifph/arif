<?php
	header("location:controller/c_tampilan.php");
?>