$(function () {
    tambahBaris();
});

function tambahBaris(){
	var div2 = document.getElementById("div1");
	div2.innerHTML+="<div class='row clearfix'>".
						"<div class='col-lg-3 col-md-2 col-sm-4 col-xs-5 form-control-label'>".
							"<label for='email_address_2'>Nama Lokasi Terdekat</label>".
						"</div>".
						"<div class='col-lg-9 col-md-10 col-sm-8 col-xs-7'>".
							"<div class='form-group'>".
								"<div class='form-line'>".
									"<input type='text' id='dekat' name='dekat' class='form-control' placeholder='Masukkan Nama Lokasi Terdekat' value=''>".
								"</div>".
							"</div>".
						"</div>".
					"</div>";
}